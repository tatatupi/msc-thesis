# latex
Exemplos de documentos LaTex para escrita de dissertação e tese, usados anteriormente por alunos do MACSIN
